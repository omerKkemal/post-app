<x-app-layout>
    <!-- Main Content -->
    <div class="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
       <!-- Language toggle -->
        <div class="p-6 bg-white rounded-lg shadow-sm border border-gray-100">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                    <svg class="w-5 h-5 mr-2 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"></path>
                    </svg>
                    Language Filter
                </h3>
                <button id="reset-language-filter" class="text-sm text-blue-600 hover:text-blue-800 transition-colors">
                    Reset Filter
                </button>
            </div>
            <div class="flex flex-wrap gap-3" id="language-filters-container">
                <button class="filter-btn language-filter-btn" data-language="english">
                    <span class="english language-badge">English</span>
                    <span class="harari hidden1 language-badge">Harari</span>
                    <span class="amharic hidden1 language-badge">እንግሊዝኛ</span>
                </button>
                <button class="filter-btn language-filter-btn" data-language="harari">
                    <span class="english language-badge">Harari</span>
                    <span class="harari hidden1 language-badge">ሀረሪ</span>
                    <span class="amharic hidden1 language-badge">ሀረሪ</span>
                </button>
                <button class="filter-btn language-filter-btn" data-language="amharic">
                    <span class="english language-badge">Amharic</span>
                    <span class="harari hidden1 language-badge">አማርኛ</span>
                    <span class="amharic hidden1 language-badge">አማርኛ</span>
                </button>
            </div>
        </div>

        <!-- Slideshow Section -->
        <section class="py-8 bg-white">
            <div class="max-w-7xl mx-auto px-4">
                <div class="overflow-hidden1 rounded-xl shadow-lg fade-in relative">
                    <!-- Fixed Text Overlay -->
                    <div class="absolute inset-0 z-10 flex flex-col items-center justify-center text-center px-4">
                        <h1 class="english text-4xl md:text-6xl font-bold mb-6 text-white drop-shadow-lg">
                            Harari Congress
                        </h1>
                        <h1 class="harari hidden1 text-4xl md:text-6xl font-bold mb-6 text-white drop-shadow-lg">
                            ሀረሪ መጀሊስ
                        </h1>
                        <h1 class="amharic hidden1 text-4xl md:text-6xl font-bold mb-6 text-white drop-shadow-lg">
                            ሀረሪ ኮንግረስ
                        </h1>
                        <p class="english text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-white drop-shadow-lg">
                            Preserving the rich heritage and culture of Harar while building a prosperous future for our community
                        </p>
                        <p class="harari hidden1 text-lg md:text-xl mb-4 max-w-2xl mx-auto text-white drop-shadow-lg">
                            ዚሀረሪ ሳዮት ቁራስ ዋ አዳች መቄረሕቤ ዳይሐዋዝዚኛሌ ዚሳይቲ ሙስተቅበል መቼኻል ላአይቤ.
                        </p>
                        <p class="amharic hidden1 text-lg md:text-xl mb-4 max-w-2xl mx-auto text-white drop-shadow-lg">
                            የሀረር ባህላዊ ርህራሄ እና ባህል በማስተያየት ለማህበራችን የሚለምን የተሻለ ምህዳር በመስራት ላይ ነን።
                        </p>
                        <div class="flex flex-wrap justify-center gap-4 mt-8">
                            <a href="#messaging"
                            class="english bg-white text-green-700 hover:bg-green-50 font-semibold py-3 px-6 rounded-lg transition duration-300 shadow-lg">
                                <i class="fas fa-bullhorn mr-2"></i>Community Messages
                            </a>
                            <a href="#messaging"
                            class="harari hidden1 bg-white text-green-700 hover:bg-green-50 font-semibold py-3 px-6 rounded-lg transition duration-300 shadow-lg">
                                <i class="fas fa-bullhorn mr-2"></i>ዚዳይሐዋዞ ሉኽ
                            </a>
                            <a href="#messaging"
                            class="amharic hidden1 bg-white text-green-700 hover:bg-green-50 font-semibold py-3 px-6 rounded-lg transition duration-300 shadow-lg">
                                <i class="fas fa-bullhorn mr-2"></i>የማህበራዊ መልእክቶች
                            </a>
                            <a href="#news"
                            class="english bg-amber-500 hover:bg-amber-600 text-white font-semibold py-3 px-6 rounded-lg transition duration-300 shadow-lg">
                                <i class="fas fa-newspaper mr-2"></i>Latest News
                            </a>
                            <a href="#news"
                            class="harari hidden1 bg-amber-500 hover:bg-amber-600 text-white font-semibold py-3 px-6 rounded-lg transition duration-300 shadow-lg">
                                <i class="fas fa-newspaper mr-2"></i>ቁራ ወቅቲ ኻበራች
                            </a>
                            <a href="#news"
                            class="amharic hidden1 bg-amber-500 hover:bg-amber-600 text-white font-semibold py-3 px-6 rounded-lg transition duration-300 shadow-lg">
                                <i class="fas fa-newspaper mr-2"></i>የቅርቡ ዜናዎች
                            </a>
                        </div>
                    </div>

                    <!-- Slideshow Images -->
                    <div class="relative h-96 md:h-screen max-h-[80vh]">
                        @foreach([1,2,3,4,5,6,7,8,9,10,11,12,13] as $index)
                        <div class="absolute inset-0 w-full h-full slideshow-image {{ $index === 1 ? 'opacity-100' : 'opacity-0' }}">
                            <img width="100%" src="{{ asset('images/harar' . $index . '.jpg') }}" alt="Harar City" class="w-full h-full object-cover">
                            <div class="absolute inset-0 bg-black bg-opacity-50"></div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>

        <!-- Culture Section -->
        <section id="culture" class="py-16 bg-white">
            <div class="max-w-7xl mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="english text-3xl md:text-4xl font-bold text-gray-800 mb-4">Harari Culture</h2>
                    <h2 class="harari hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ዚሀረሪ አዳ</h2>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="bg-green-50 rounded-xl p-6 text-center fade-in">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-language text-green-600 text-2xl"></i>
                        </div>
                        <h3 class="english text-xl font-semibold text-gray-800 mb-3">Harari Language</h3>
                        <h3 class="amharic hidden1 text-xl font-semibold text-gray-800 mb-3">የሀረር ቋንቋ</h3>
                        <h3 class="harari hidden1 text-xl font-semibold text-gray-800 mb-3">ሀረሪ ሉኃ</h3>
                        <p class="english text-gray-600">Learn about the unique Harari language (Gey Sinan) and its preservation efforts</p>
                        <p class="amharic hidden1 text-gray-600">ስለ የሀረር የተለየ ቋንቋ (Gey Sinan) እና የማስተናገዱ ጥረቶች ያገኙ።</p>
                        <p class="harari hidden1 text-gray-600">ሀረሪ ሉኃ ኔሮት ዋ ቄረሖት ኩሽኩሽቲው ዩቁ.</p>
                    </div>

                    <div class="bg-amber-50 rounded-xl p-6 text-center fade-in" style="animation-delay: 0.1s">
                        <div class="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-utensils text-amber-600 text-2xl"></i>
                        </div>
                        <h3 class="english text-xl font-semibold text-gray-800 mb-3">Traditional Cuisine</h3>
                        <h3 class="amharic hidden1 text-xl font-semibold text-gray-800 mb-3">የባህላዊ ምግብ</h3>
                        <h3 class="harari hidden1 text-xl font-semibold text-gray-800 mb-3">አዳ ሐንጉራች</h3>
                        <p class="english text-gray-600">Explore the unique flavors and dishes of Harari culinary traditions</p>
                        <p class="amharic hidden1 text-gray-600">የሀረር ባህላዊ ምግብን እና የእርስዎን ጣዕሙ ያገኙ።</p>
                        <p class="harari hidden1 text-gray-600">ሀረሪ አዳ ሐንጉራች ሲነታች ዋ ሉይ ጢማቹ የፌሕሱ</p>
                    </div>

                    <div class="bg-red-50 rounded-xl p-6 text-center fade-in" style="animation-delay: 0.2s">
                        <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-praying-hands text-red-600 text-2xl"></i>
                        </div>
                        <h3 class="english text-xl font-semibold text-gray-800 mb-3">Shuwalid festival and mawlid</h3>
                        <h3 class="amharic hidden1 text-xl font-semibold text-gray-800 mb-3">በሹዋልና በመውልድ በሚደረገው በዓል ላይ</h3>
                        <h3 class="harari hidden1 text-xl font-semibold text-gray-800 mb-3">ሹዋል ኢድ ዋ መውሉድ</h3>
                        <p class="english text-gray-600">celebrating Shuwalid festival and prophet muhammad peace be upon him mawlid</p>
                        <p class="amharic hidden1 text-gray-600">በሹዋል በዓልና በነቢዩ ሙሐመድ መውልድ ልዩ ማኅበረ ሰብ መደምደሚያን እናገናኝ።</p>
                        <p class="harari hidden1 text-gray-600">ዚሀረሪ መሐድ ሹዋል ኢድ ዋ መውሉድ መግደርቲ ሒራች ዋ ተቃሊዳች</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- History Section -->
        <section id="history" class="py-16 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="english text-3xl md:text-4xl font-bold text-gray-800 mb-4">History of Harar</h2>
                    <h2 class="amharic hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">የሐረር ታሪክ</h2>
                    <h2 class="harari hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ዚሀረሪ ታሪኽ</h2>
                    <p class="english text-gray-600 max-w-2xl mx-auto">Explore the ancient walled city and its significant historical legacy</p>
                    <p class="amharic hidden1 text-gray-600 max-w-2xl mx-auto">ጥንታዊውን በግንብ የተከበበችውን ከተማ እና ጉልህ ታሪካዊ ቅርሶቿን ያስሱ</p>
                    <p class="harari hidden1 text-gray-600 max-w-2xl mx-auto">ቀዲም ጆጎል ሑጡርቤ ዚትቼኻልቲ አሲማ ዋ በግዚታ ታሪኽ ዋ ቁራሳች ዛሌ</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                    <div class="fade-in">
                        <div class="bg-white rounded-xl shadow-lg p-6">
                            <h3 class="english text-2xl font-bold text-gray-800 mb-4">The Walled City</h3>
                            <h3 class="amharic hidden1 text-2xl font-bold text-gray-800 mb-4">ቅጥር ከተማ</h3>
                            <h3 class="harari hidden1 text-2xl font-bold text-gray-800 mb-4">ዚትሔጠርቲ አሲማ</h3>
                            <p class="english text-gray-600 mb-4">
                                Harar Jugol, the historic fortified city, is a UNESCO World Heritage Site with 82 mosques
                                and 102 shrines, representing the most important Islamic historical city in the Horn of Africa.
                            </p>
                            <p class="amharic hidden1 text-gray-600 mb-4">
                                ታሪካዊቷ የተመሸገችው ሀረር ጁጎል በዩኔስኮ በአለም ቅርስነት የተመዘገበች ሲሆን 82 መስጊዶች እና 102 መቅደሶች ያሉት ሲሆን ይህም በአፍሪካ ቀንድ ውስጥ እጅግ አስፈላጊ የሆነች የእስልምና ታሪካዊ ከተማ ነች።
                            </p>
                            <p class="harari hidden1 text-gray-600 mb-4">
                                ታሪኺያ ዚቴማ ዚትሼመቅቲ ሀረር ጆጎል ዩኒስኮ አለም ሑቁፍ ታሪኽ ቁራስነትቤ ሲትሴጀልቲ ዚኻነሳአ 82 መስጂዳች 102 አዋቻች ዛሉ ዚኻነሳአ ዩም ቀር አፍሪካቤ ተትኺሽዛት ዚኻንቲ ዚኢስላሚያ ታሪኺያ አሲማነንቴ
                            </p>
                            <ul class="english space-y-2 text-gray-600">
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>Founded in the 7th century</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>Capital of the Harari Kingdom from 1520 to 1568</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>Important center for Islamic learning and trade</span>
                                </li>
                            </ul>
                            <ul class="amharic hidden1 space-y-2 text-gray-600">
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>በ 7 ኛው ክፍለ ዘመን የተመሰረተ</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>የሐረሪ መንግሥት ዋና ከተማ ከ1520 እስከ 1568 ዓ.ም</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>ለእስልምና ትምህርት እና ንግድ ጠቃሚ ማዕከል</span>
                                </li>
                            </ul>
                            <ul class="harari hidden1 space-y-2 text-gray-600">
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>7ታኝ ቀርኒ ዘማንቤ ዚትኤሰስቲ</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>ዚሀረሪ አሲማ 1520 ኢላዋ 1568 አመት</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                    <span>ዚኢስላም ዲን ደርሲ ዋ ቲጃራ ቲነፊዛት ኡድ</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="fade-in" style="animation-delay: 0.1s">
                        <div class="bg-gradient-to-br from-green-500 to-green-700 rounded-xl p-8 text-white">
                            <h3 class="english text-2xl font-bold mb-4">Historical Timeline</h3>
                            <h3 class="amharic hidden1 text-2xl font-bold mb-4">ታሪካዊ የጊዜ መስመር</h3>
                            <h3 class="harari hidden1 text-2xl font-bold mb-4">ታሪኺያ ዚወቅቲ መስጣራ</h3>
                            <div class="space-y-4">
                                <div class="flex items-center">
                                    <div class="bg-white text-green-700 w-20 h-8 rounded-full flex items-center justify-center text-sm font-bold mr-4">
                                        <span class="english">7th C</span>
                                        <span class="amharic hidden1">7ኛ ሲ</span>
                                        <span class="harari hidden1">7ኛ ቀርኒ</span>
                                    </div>
                                    <div>
                                        <p class="english">Foundation of Harar</p>
                                        <p class="amharic hidden1">የሐረር መሠረት</p>
                                        <p class="harari hidden1">ሀረሪ አስሊ</p>
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <div class="bg-white text-green-700 w-20 h-8 rounded-full flex items-center justify-center text-sm font-bold mr-4">
                                        <span class="english">1520</span>
                                        <span class="amharic hidden1">1520</span>
                                        <span class="harari hidden1">1520</span>
                                    </div>
                                    <div>
                                        <p class="english">Capital of Harari Kingdom</p>
                                        <p class="amharic hidden1">የሀረሪ ግዛት ዋና ከተማ</p>
                                        <p class="harari hidden1">ሀረሪ ሑኩማ ዋና አሲማ</p>
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <div class="bg-white text-green-700 w-20 h-8 rounded-full flex items-center justify-center text-sm font-bold mr-4">
                                        <span class="english">1887</span>
                                        <span class="amharic hidden1">1887</span>
                                        <span class="harari hidden1">1887</span>
                                    </div>
                                    <div>
                                        <p class="english">Incorporation into Ethiopia</p>
                                        <p class="amharic hidden1">ወደ ኢትዮጵያ መግባት</p>
                                        <p class="harari hidden1">ኪም ኢቶጲያ ሑኩማ</p>
                                    </div>
                                </div>
                                <div class="flex items-center">
                                    <div class="bg-white text-green-700 w-20 h-8 rounded-full flex items-center justify-center text-sm font-bold mr-4">
                                        <span class="english">2006</span>
                                        <span class="amharic hidden1">2006</span>
                                        <span class="harari hidden1">2006</span>
                                    </div>
                                    <div>
                                        <p class="english">UNESCO World Heritage</p>
                                        <p class="amharic hidden1">የዩኔስኮ የዓለም ቅርስ</p>
                                        <p class="harari hidden1">ዩኒስኮ አለም ሑቁፍ ቁራስ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Handicrafts Section -->
        <section id="handicrafts" class="py-16 bg-white">
            <div class="max-w-7xl mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="english text-3xl md:text-4xl font-bold text-gray-800 mb-4">Traditional Handicrafts</h2>
                    <h2 class="harari hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ዚአዳ ኢጂ ሲነታች</h2>
                    <p class="english text-gray-600 max-w-2xl mx-auto">Exquisite handmade items showcasing Harari artistry and heritage</p>
                    <p class="harari hidden1 text-gray-600 max-w-2xl mx-auto">ዚሀረሪ ሲነት ዋ ቁራሱ ያርዛሉ አጃኢብ ዚተዩ ኢጂቤ ዚትደለጉ መሐዋች</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div class="bg-amber-50 rounded-xl overflow-hidden1 shadow-md fade-in">
                        <div class="h-48 bg-amber-200 flex items-center justify-center">
                            <i class="fas fa-basket-shopping text-amber-600 text-5xl"></i>
                        </div>
                        <div class="p-4">
                            <h3 class="english text-xl font-semibold text-gray-800 mb-2">Basketry</h3>
                            <h3 class="amharic hidden1 text-xl font-semibold text-gray-800 mb-2">ቅርጫት</h3>
                            <h3 class="harari hidden1 text-xl font-semibold text-gray-800 mb-2">ሞታች</h3>
                            <p class="english text-gray-600 text-sm">Intricately woven baskets with traditional patterns</p>
                            <p class="amharic hidden1 text-gray-600 text-sm">ከባህላዊ ቅጦች ጋር ውስብስብ የሆነ የተጠለፉ ቅርጫቶች</p>
                            <p class="harari hidden1 text-gray-600 text-sm">አዳ ሲነታችቤ ዚትደለጉ አጃኢብ ዚተዩ ኢጂቤ ዚትሰፉ ሞታች</p>
                        </div>
                    </div>

                    <div class="bg-green-50 rounded-xl overflow-hidden1 shadow-md fade-in" style="animation-delay: 0.1s">
                        <div class="h-48 bg-green-200 flex items-center justify-center">
                            <i class="fas fa-tshirt text-green-600 text-5xl"></i>
                        </div>
                        <div class="p-4">
                            <h3 class="english text-xl font-semibold text-gray-800 mb-2">Textiles</h3>
                            <h3 class="amharic hidden1 text-xl font-semibold text-gray-800 mb-2">ጨርቃ ጨርቅ</h3>
                            <h3 class="harari hidden1 text-xl font-semibold text-gray-800 mb-2">ጨርቂቤ</h3>
                            <p class="english text-gray-600 text-sm">Traditional Harari clothing and fabric designs</p>
                            <p class="amharic hidden1 text-gray-600 text-sm">የሀረሪ ባህላዊ አልባሳት እና የጨርቃጨርቅ ንድፎች</p>
                            <p class="harari hidden1 text-gray-600 text-sm">ሀረሪ አዳ ሊባሻች ዋ ጨርቂቤ ዚደለጉ ሲነታች</p>
                        </div>
                    </div>

                    <div class="bg-red-50 rounded-xl overflow-hidden1 shadow-md fade-in" style="animation-delay: 0.2s">
                        <div class="h-48 bg-red-200 flex items-center justify-center">
                            <i class="fas fa-gem text-red-600 text-5xl"></i>
                        </div>
                        <div class="p-4">
                            <h3 class="english text-xl font-semibold text-gray-800 mb-2">Jewelry</h3>
                            <h3 class="amharic hidden1 text-xl font-semibold text-gray-800 mb-2">ጌጣጌጥ</h3>
                            <h3 class="harari hidden1 text-xl font-semibold text-gray-800 mb-2">ሰያቅ</h3>
                            <p class="english text-gray-600 text-sm">Silver and beadwork with cultural significance</p>
                            <p class="amharic hidden1 text-gray-600 text-sm">ከባህላዊ ጠቀሜታ ጋር የብር እና የበቆሎ ስራዎች</p>
                            <p class="harari hidden1 text-gray-600 text-sm">ሀረሪ አዳ ሊባሻች ማቤይነቤ ዚደለጉ ዚትሊያያ ዲዛይቤ ዚትደለጉ ሰያቅ ዲላጋች</p>
                        </div>
                    </div>

                    <div class="bg-blue-50 rounded-xl overflow-hidden1 shadow-md fade-in" style="animation-delay: 0.3s">
                        <div class="h-48 bg-blue-200 flex items-center justify-center">
                            <i class="fas fa-paint-brush text-blue-600 text-5xl"></i>
                        </div>
                        <div class="p-4">
                            <h3 class="english text-xl font-semibold text-gray-800 mb-2">Pottery</h3>
                            <h3 class="amharic hidden1 text-xl font-semibold text-gray-800 mb-2">የሸክላ ዕቃዎች</h3>
                            <h3 class="harari hidden1 text-xl font-semibold text-gray-800 mb-2">አፈር ጌብ</h3>
                            <p class="english text-gray-600 text-sm">Traditional clay works with unique Harari motifs</p>
                            <p class="amharic hidden1 text-gray-600 text-sm">ባህላዊ ሸክላ ልዩ በሆኑ የሐረሪ ዘይቤዎች ይሠራል</p>
                            <p class="harari hidden1 text-gray-600 text-sm">ዚአዳ አፈር ጌብ ሉይ ዚኻና ኡጋቤ ሀረሪ ተቃሊድ ቤ ዚትደለጉ ኢጂ ሲነታች</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Messaging Section -->
        <section id="messaging" class="py-16 bg-green-50">
            <div class="max-w-7xl mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="english text-3xl md:text-4xl font-bold text-gray-800 mb-4">Community Messaging</h2>
                    <h2 class="amharic hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">የማህበረሰብ መልእክት</h2>
                    <h2 class="harari hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ዳይሐዋዞ ሉኽ</h2>
                    <p class="english text-gray-600 max-w-2xl mx-auto">Stay connected with important announcements and community updates</p>
                    <p class="amharic hidden1 text-gray-600 max-w-2xl mx-auto">አስፈላጊ ከሆኑ ማስታወቂያዎች እና የማህበረሰብ ዝመናዎች ጋር እንደተገናኙ ይቆዩ</p>
                    <p class="harari hidden1 text-gray-600 max-w-2xl mx-auto">አትኼሽ ዚኻኑ አቴወቆታች ዋ ዳይሐዋዝ ዘማኒያችባሕ ዚትራአ ኩትቤ ዩነብራል ዚቁራ ዳይሐዋዝ ሉኻች</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Recent Messages -->
                    <div class="fade-in" style="animation-delay: 0.1s">
                        <h3 class="english text-2xl font-bold text-gray-800 mb-6">Recent Community Messages</h3>
                        <h3 class="amharic hidden1 text-2xl font-bold text-gray-800 mb-6">የቅርብ ጊዜ የማህበረሰብ መልዕክቶች</h3>
                        <h3 class="harari hidden1 text-2xl font-bold text-gray-800 mb-6">ቁራ ወቅቲ ዚዳይሐዋዞ ሉኽ</h3>
                        <div class="space-y-4">
                            @if(isset($messages) && count($messages) > 0)
                                @foreach($messages as $message)
                                    @if ($message->language == 'eng')
                                        <div class="english bg-white rounded-lg shadow p-4">
                                            <h4 class="font-semibold text-green-700 mb-2">{{ $message->title ?? 'No Title' }}</h4>
                                            <p class="text-gray-600 text-sm mb-2">{{ $message->description ?? 'No description' }}</p>
                                            <span class="text-xs text-gray-500">Posted on {{ $message->created_at->format('M d, Y') ?? 'Unknown date' }}</span>
                                        </div>
                                    @elseif ($message->language == 'har')
                                        <div class="harari hidden1 bg-white rounded-lg shadow p-4">
                                            <h4 class="font-semibold text-green-700 mb-2">{{ $message->title ?? 'No Title' }}</h4>
                                            <p class="text-gray-600 text-sm mb-2">{{ $message->description ?? 'No description' }}</p>
                                            <span class="text-xs text-gray-500">Posted on {{ $message->created_at->format('M d, Y') ?? 'Unknown date' }}</span>
                                        </div>
                                    @endif
                                @endforeach
                            @else
                                <div class="bg-white rounded-lg shadow p-4 text-center">
                                    <p class="text-gray-600">No messages available</p>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Additional Content Placeholder -->
                    <div class="fade-in" style="animation-delay: 0.2s">
                        <div class="bg-white rounded-xl p-6 h-full">
                            <h3 class="english text-2xl font-bold text-gray-800 mb-6">Get Involved</h3>
                            <h3 class="amharic hidden1 text-2xl font-bold text-gray-800 mb-6">ተሳተፍ</h3>
                            <h3 class="harari hidden1 text-2xl font-bold text-gray-800 mb-6">ዳይሐዋዞ ተሳአዶት</h3>
                            <p class="english text-gray-600 mb-4">Join our community discussions and stay updated with the latest announcements.</p>
                            <p class="amharic hidden1 text-gray-600 mb-4">የእኛን የማህበረሰብ ውይይቶች ይቀላቀሉ እና በቅርብ ጊዜ ማስታወቂያዎች እንደተዘመኑ ይቆዩ።</p>
                            <p class="harari hidden1 text-gray-600 mb-4">ዳይ ሀዋዚያ  ተሳአዶት ኡሹማ ቁራ ወቅቲ አቴውቅታች ሪኸቡ</p>
                            <div class="english space-y-3">
                                <div class="flex items-center">
                                    <i class="fas fa-calendar-check text-green-500 mr-3"></i>
                                    <span>Community meetings</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-bullhorn text-amber-500 mr-3"></i>
                                    <span>Emergency alerts and announcements</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-handshake text-blue-500 mr-3"></i>
                                    <span>Volunteer opportunities</span>
                                </div>
                            </div>
                            <div class="amharic hidden1 space-y-3">
                                <div class="flex items-center">
                                    <i class="fas fa-calendar-check text-green-500 mr-3"></i>
                                    <span>የማህበረሰብ ስብሰባዎች</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-bullhorn text-amber-500 mr-3"></i>
                                    <span>የአደጋ ጊዜ ማንቂያዎች እና ማስታወቂያዎች</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-handshake text-blue-500 mr-3"></i>
                                    <span>የበጎ ፈቃደኝነት እድሎች</span>
                                </div>
                            </div>
                            <div class="harari hidden1 space-y-3">
                                <div class="flex items-center">
                                    <i class="fas fa-calendar-check text-green-500 mr-3"></i>
                                    <span>ዳይ ሀዋዚያ ዲብላናች</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-bullhorn text-amber-500 mr-3"></i>
                                    <span>ዳይ ሀዋዚያ አቴውቅታች</span>
                                </div>
                                <div class="flex items-center">
                                    <i class="fas fa-handshake text-blue-500 mr-3"></i>
                                    <span>ኸይሪባይ ትሳአዳች</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Congress Section -->
        <section id="congress" class="py-16 bg-white">
            <div class="max-w-7xl mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="english text-3xl md:text-4xl font-bold text-gray-800 mb-4">Harari Congress</h2>
                    <h2 class="amharic hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">የሐረሪ ኮንግረስ</h2>
                    <h2 class="harari hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ሀረሪ መጀሊስ</h2>
                    <p class="english text-gray-600 max-w-2xl mx-auto">Governing body representing the Harari people and their interests</p>
                    <p class="amharic hidden1 text-gray-600 max-w-2xl mx-auto">የሀረሪ ህዝብ እና ጥቅማቸውን የሚወክል የበላይ አካል</p>
                    <p class="harari hidden1 text-gray-600 max-w-2xl mx-auto">ሀረሪ መሐድ መጅሊስ ተዋቀሮት</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="fade-in">
                        <div class="bg-gradient-to-br from-green-600 to-green-800 rounded-xl p-8 text-white">
                            <h3 class="text-2xl font-bold mb-6">Congress Leadership</h3>
                            <div class="space-y-6">
                                @if(isset($congress_members) && count($congress_members) > 0)
                                    @foreach ($congress_members as $member)
                                        <div class="flex items-center">
                                            <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center mr-4">
                                                @if(isset($member->photo_url) && !empty($member->photo_url))
                                                    <img src="{{ Storage::url($member->photo_url) }}"
                                                         alt="{{ $member->name ?? 'Member' }}"
                                                         class="w-14 h-14 rounded-full object-cover">
                                                @else
                                                    <i class="fas fa-user text-green-600 text-2xl"></i>
                                                @endif
                                            </div>
                                            <div>
                                                <h4 class="font-semibold text-lg">{{ $member->name ?? 'Unknown Name' }}</h4>
                                                <p class="text-sm">{{ $member->position ?? 'No position specified' }}</p>
                                            </div>
                                        </div>
                                    @endforeach
                                @else
                                    <p class="text-center">No congress members data available</p>
                                @endif
                            </div>
                        </div>
                    </div>

                    <div class="fade-in" style="animation-delay: 0.1s">
                        <div class="english bg-gray-50 rounded-xl p-8">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6">Congress Activities</h3>
                            <ul class="space-y-4">
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">Cultural preservation initiatives</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">Community development projects</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">Educational programs</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">Representation in regional government</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">Heritage site preservation</span>
                                </li>
                            </ul>
                        </div>
                        <div class="amharic hidden1 bg-gray-50 rounded-xl p-8">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6">የኮንግረስ እንቅስቃሴዎች</h3>
                            <ul class="space-y-4">
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">የባህል ጥበቃ ተነሳሽነት</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">የማህበረሰብ ልማት ፕሮጀክቶች</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">የትምህርት ፕሮግራሞች</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">በክልል መንግስት ውስጥ ውክልና</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">የቅርስ ቦታ ጥበቃ</span>
                                </li>
                            </ul>
                        </div>

                        <div class="harari hidden1 bg-gray-50 rounded-xl p-8">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6">ሀረሪ መጅሊስ ኩሽኩሽቲያች</h3>
                            <ul class="space-y-4">
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">አዳ ቄረሖት ሐፈ ሐፍቲ</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">ማሐዲያ ኔሮት ፕሮጀክቲ</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">ደርሲ በርናሚጃች</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">ሑስኒዞ ሑኩማ ኡስጡቤ ተዌከሎት</span>
                                </li>
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                                    <span class="text-gray-700">ቁራስ አታይ ቄረሖት</span>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <!-- News Section -->
        <section id="news" class="py-16 bg-gray-50">
            <div class="text-center mb-12">
                <h2 class="english text-3xl md:text-4xl font-bold text-gray-800 mb-4">Latest News</h2>
                <h2 class="amharic hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">የቅርብ ጊዜ ዜናዎች</h2>
                <h2 class="harari hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ቁራ ወቅቲ ኻበራች</h2>
                <p class="english text-gray-600 max-w-2xl mx-auto">Stay updated with the latest developments in the Harari community</p>
                <p class="amharic hidden1 text-gray-600 max-w-2xl mx-auto">በሐረሪ ማህበረሰብ ውስጥ ባሉ አዳዲስ ክስተቶች ወቅታዊ መረጃዎችን ያግኙ</p>
                <p class="harari hidden1 text-gray-600 max-w-2xl mx-auto">ሀረሪ ሑስኒቤ ዛሉ ሐጂስ ሐጂስ ሩኹብቲያቹ ዋ ወቅቲያ ማእሉማታች የርኸቡ</p>
            </div>

            <!-- English News -->
            <div class="english max-w-7xl mx-auto px-4">
                @if(isset($recent_english_posts) && count($recent_english_posts) > 0)
                    @foreach($recent_english_posts as $post)
                        @if ($post->category != 'message')
                            <div class="bg-white rounded-xl shadow-md mb-6 p-6 fade-in">
                                <h3 class="text-xl font-bold text-gray-800 mb-2">{{ $post->title ?? 'No Title' }}</h3>
                                <p class="text-gray-600 text-sm mb-4">{{ Str::limit($post->description ?? 'No description available', 150) }}</p>
                            </div>
                        @endif
                    @endforeach
                @else
                    <div class="bg-white rounded-xl shadow-md p-6 text-center">
                        <p class="text-gray-600">No English news available</p>
                    </div>
                @endif
            </div>

            <!-- Harari News -->
            <div class="harari hidden1 max-w-7xl mx-auto px-4">
                @if(isset($recent_harari_posts) && count($recent_harari_posts) > 0)
                    @foreach($recent_harari_posts as $post)
                        @if ($post->category != 'message')
                            <div class="bg-white rounded-xl shadow-md mb-6 p-6 fade-in">
                                <h3 class="text-xl font-bold text-gray-800 mb-2">{{ $post->title ?? 'No Title' }}</h3>
                                <p class="text-gray-600 text-sm mb-4">{{ Str::limit($post->description ?? 'No description available', 150) }}</p>
                            </div>
                        @endif
                    @endforeach
                @else
                    <div class="bg-white rounded-xl shadow-md p-6 text-center">
                        <p class="text-gray-600">ሀረሪ ኻበራች አይተኻነስአ</p>
                    </div>
                @endif
            </div>
        </section>

        <!-- Laws Section with PDF Preview Modal -->
        <section id="laws" class="py-16 bg-white">
            <div class="max-w-7xl mx-auto px-4">
                <div class="text-center mb-12">
                    <h2 class="english text-3xl md:text-4xl font-bold text-gray-800 mb-4">Laws & Regulations</h2>
                    <h2 class="amharic hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ህጎች እና መመሪያዎች</h2>
                    <h2 class="harari hidden1 text-3xl md:text-4xl font-bold text-gray-800 mb-4">ቃኑናች ዋ መኤቀድቲ</h2>
                    <p class="english text-gray-600 max-w-2xl mx-auto">Governing laws and community regulations for the Harari people</p>
                    <p class="amharic hidden1 text-gray-600 max-w-2xl mx-auto">ለሀረሪ ህዝብ የአስተዳደር ህጎች እና የማህበረሰብ መመሪያዎች</p>
                    <p class="harari hidden1 text-gray-600 max-w-2xl mx-auto">ዚሀረሪ መሐድ መጅሊስ መትሒዳደርቲ ቃኑናች ዋ ዳይሐዋዝ መኤቀድቲያች</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    @if(isset($law_posts) && count($law_posts) > 0)
                        @foreach ($law_posts as $law)
                            <!-- English Version -->
                            <div class="english bg-gray-50 rounded-xl p-6 fade-in hover:shadow-lg transition-shadow duration-300">
                                <h3 class="text-xl font-bold text-gray-800 mb-2">{{ $law->name ?? 'No Title' }}</h3>
                                <p class="text-gray-600 text-sm mb-4">{{ Str::limit($law->description ?? 'No description available', 200) }}</p>
                                
                                @if(isset($law->location) && !empty($law->location))
                                    @php
                                        $isUrl = filter_var($law->location, FILTER_VALIDATE_URL);
                                        $pdfPath = $isUrl ? $law->location : asset('storage/' . $law->location);
                                    @endphp
                                    <div class="flex flex-wrap gap-3 mt-4 pt-4 border-t border-gray-200">
                                        <button onclick="openPDFViewer('{{ $pdfPath }}', '{{ $law->name }}')" 
                                                class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition duration-300 text-sm">
                                            <i class="fas fa-eye mr-2"></i>
                                            Preview PDF
                                        </button>
                                        <a href="{{ $pdfPath }}" 
                                           download 
                                           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition duration-300 text-sm">
                                            <i class="fas fa-download mr-2"></i>
                                            Download
                                        </a>
                                    </div>
                                @else
                                    <div class="mt-4 pt-4 border-t border-gray-200">
                                        <span class="text-gray-400 text-sm">No PDF available</span>
                                    </div>
                                @endif
                            </div>

                            <!-- Harari Version -->
                            <div class="harari hidden1 bg-gray-50 rounded-xl p-6 fade-in hover:shadow-lg transition-shadow duration-300">
                                <h3 class="text-xl font-bold text-gray-800 mb-2">{{ $law->name ?? 'No Title' }}</h3>
                                <p class="text-gray-600 text-sm mb-4">{{ Str::limit($law->description ?? 'No description available', 200) }}</p>
                                
                                @if(isset($law->location) && !empty($law->location))
                                    @php
                                        $isUrl = filter_var($law->location, FILTER_VALIDATE_URL);
                                        $pdfPath = $isUrl ? $law->location : asset('storage/' . $law->location);
                                    @endphp
                                    <div class="flex flex-wrap gap-3 mt-4 pt-4 border-t border-gray-200">
                                        <button onclick="openPDFViewer('{{ $pdfPath }}', '{{ $law->name }}')" 
                                                class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition duration-300 text-sm">
                                            <i class="fas fa-eye mr-2"></i>
                                            ፒዲኤፍ ይመልከቱ
                                        </button>
                                        <a href="{{ $pdfPath }}" 
                                           download 
                                           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition duration-300 text-sm">
                                            <i class="fas fa-download mr-2"></i>
                                            አውርድ
                                        </a>
                                    </div>
                                @else
                                    <div class="mt-4 pt-4 border-t border-gray-200">
                                        <span class="text-gray-400 text-sm">ፒዲኤፍ የለም</span>
                                    </div>
                                @endif
                            </div>

                            <!-- Amharic Version -->
                            <div class="amharic hidden1 bg-gray-50 rounded-xl p-6 fade-in hover:shadow-lg transition-shadow duration-300">
                                <h3 class="text-xl font-bold text-gray-800 mb-2">{{ $law->name ?? 'No Title' }}</h3>
                                <p class="text-gray-600 text-sm mb-4">{{ Str::limit($law->description ?? 'No description available', 200) }}</p>
                                
                                @if(isset($law->location) && !empty($law->location))
                                    @php
                                        $isUrl = filter_var($law->location, FILTER_VALIDATE_URL);
                                        $pdfPath = $isUrl ? $law->location : asset('storage/' . $law->location);
                                    @endphp
                                    <div class="flex flex-wrap gap-3 mt-4 pt-4 border-t border-gray-200">
                                        <button onclick="openPDFViewer('{{ $pdfPath }}', '{{ $law->name }}')" 
                                                class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition duration-300 text-sm">
                                            <i class="fas fa-eye mr-2"></i>
                                            ፒዲኤፍ ይመልከቱ
                                        </button>
                                        <a href="{{ $pdfPath }}" 
                                           download 
                                           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition duration-300 text-sm">
                                            <i class="fas fa-download mr-2"></i>
                                            አውርድ
                                        </a>
                                    </div>
                                @else
                                    <div class="mt-4 pt-4 border-t border-gray-200">
                                        <span class="text-gray-400 text-sm">ፒዲኤፍ የለም</span>
                                    </div>
                                @endif
                            </div>
                        @endforeach
                    @else
                        <div class="col-span-2 text-center py-8">
                            <p class="text-gray-500">No laws and regulations available at the moment.</p>
                        </div>
                    @endif
                </div>
            </div>
        </section>
    </div>

    <!-- PDF Viewer Modal -->
    <div id="pdfViewerModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black bg-opacity-75">
        <div class="bg-white rounded-xl shadow-2xl w-11/12 max-w-5xl h-[90vh] flex flex-col">
            <!-- Modal Header -->
            <div class="flex items-center justify-between p-4 border-b border-gray-200">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-file-pdf text-red-500 text-xl"></i>
                    <h3 class="text-lg font-semibold text-gray-800" id="pdfViewerName">PDF Document</h3>
                </div>
                <button onclick="closePDFViewer()" class="text-gray-400 hover:text-gray-600 transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="flex-1 p-4 bg-gray-100">
                <iframe id="pdfViewerIframe" src="" class="w-full h-full rounded-lg border-0" frameborder="0"></iframe>
            </div>
            <!-- Modal Footer -->
            <div class="flex justify-end p-4 border-t border-gray-200 bg-gray-50">
                <button onclick="closePDFViewer()" class="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg transition duration-300">
                    Close
                </button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Slideshow functionality
            const slides = document.querySelectorAll('.slideshow-image');
            let currentIndex = 0;
            let slideInterval = null;

            function showSlide(index) {
                slides.forEach((slide, i) => {
                    slide.style.opacity = i === index ? '1' : '0';
                });
            }

            function nextSlide() {
                currentIndex = (currentIndex + 1) % slides.length;
                showSlide(currentIndex);
            }

            // Initialize slideshow
            if (slides.length > 0) {
                showSlide(currentIndex);
                slideInterval = setInterval(nextSlide, 3000);

                // Pause on hover
                const slideshowContainer = document.querySelector('.relative.overflow-hidden1');
                if (slideshowContainer) {
                    slideshowContainer.addEventListener('mouseenter', () => {
                        if (slideInterval) {
                            clearInterval(slideInterval);
                            slideInterval = null;
                        }
                    });
                    slideshowContainer.addEventListener('mouseleave', () => {
                        if (!slideInterval) {
                            slideInterval = setInterval(nextSlide, 3000);
                        }
                    });
                }
            }

            // Language functionality
            // Cookie functions
            function setCookie(name, value, days) {
                const expires = new Date();
                expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
                document.cookie = name + '=' + value + ';expires=' + expires.toUTCString() + ';path=/';
            }

            function getCookie(name) {
                const nameEQ = name + '=';
                const ca = document.cookie.split(';');
                for(let i = 0; i < ca.length; i++) {
                    let c = ca[i];
                    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
                    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
                }
                return null;
            }

            const languageButtons = document.querySelectorAll('.language-filter-btn');
            const resetButton = document.getElementById('reset-language-filter');
            const toggleButton = document.getElementById('toggle-language');
            let currentLanguage = (function() {
                const saved = getCookie('selected_language');
                return (saved && saved !== 'all') ? saved : 'harari';
            })();

            function setLanguage(language) {
                currentLanguage = language;
                if (language !== 'harari') {
                    setCookie('selected_language', language, 30); // Save for 30 days
                }

                // Remove active class from all buttons
                languageButtons.forEach(btn => {
                    btn.classList.remove('active');
                });

                // Add active class to selected button
                const selectedBtn = document.querySelector(`[data-language="${language}"]`);
                if (selectedBtn) {
                    selectedBtn.classList.add('active');
                }

                // Show/hide language-specific content
                const harariElements = document.querySelectorAll('.harari');
                const englishElements = document.querySelectorAll('.english');
                const amharicElements = document.querySelectorAll('.amharic');

                // Hide all first
                harariElements.forEach(el => el.classList.add('hidden1'));
                englishElements.forEach(el => el.classList.add('hidden1'));
                amharicElements.forEach(el => el.classList.add('hidden1'));

                // Show selected language
                switch(language) {
                    case 'harari':
                        harariElements.forEach(el => el.classList.remove('hidden1'));
                        break;
                    case 'english':
                        englishElements.forEach(el => el.classList.remove('hidden1'));
                        break;
                    case 'amharic':
                        amharicElements.forEach(el => el.classList.remove('hidden1'));
                        break;
                }

                // Update toggle button text if it exists
                if (toggleButton) {
                    const isEnglish = language === 'english';
                    const englishSpan = toggleButton.querySelector('.english');
                    const harariSpan = toggleButton.querySelector('.harari');

                    if (englishSpan && harariSpan) {
                        englishSpan.classList.toggle('hidden1', !isEnglish);
                        harariSpan.classList.toggle('hidden1', isEnglish);
                    }
                }
            }

            // Toggle between English and Harari
            function toggleLanguage() {
                const nextLanguage = currentLanguage === 'english' ? 'harari' : 'english';
                setLanguage(nextLanguage);
            }

            // Add click events to language buttons
            languageButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const language = this.getAttribute('data-language');
                    setLanguage(language);
                });
            });

            // Reset button functionality
            if (resetButton) {
                resetButton.addEventListener('click', function() {
                    setLanguage('english');
                });
            }

            // Toggle button functionality
            if (toggleButton) {
                toggleButton.addEventListener('click', toggleLanguage);
            }

            // Initialize with saved language or default
            setLanguage(currentLanguage);
        });

        // PDF Viewer Functions - Only closes with buttons or Escape key
        function openPDFViewer(pdfUrl, pdfName) {
            const modal = document.getElementById('pdfViewerModal');
            const iframe = document.getElementById('pdfViewerIframe');
            const name = document.getElementById('pdfViewerName');
            
            iframe.src = pdfUrl;
            name.textContent = pdfName || 'PDF Document';
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function closePDFViewer() {
            const modal = document.getElementById('pdfViewerModal');
            const iframe = document.getElementById('pdfViewerIframe');
            modal.style.display = 'none';
            iframe.src = '';
            document.body.style.overflow = '';
        }

        // Only close with Escape key (not by clicking backdrop)
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closePDFViewer();
            }
        });
    </script>

    <style>
        .slideshow-image {
            transition: opacity 1s ease-in-out;
            background: black;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            opacity: 0;
            animation: fadeIn 0.8s ease-out forwards;
        }

        html {
            scroll-behavior: smooth;
        }

        .hidden1 {
            display: none !important;
        }

        /* Active button styling */
        .language-filter-btn.active {
            background-color: #3b82f6;
            color: white;
        }

        .language-filter-btn.active .language-badge {
            color: white;
        }

        .language-filter-btn {
            transition: all 0.2s ease;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            background-color: #f3f4f6;
            border: 1px solid #e5e7eb;
        }

        .language-filter-btn:hover {
            background-color: #e5e7eb;
        }

        /* PDF Viewer Modal Styles */
        #pdfViewerModal {
            background-color: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
        }
    </style>
</x-app-layout>