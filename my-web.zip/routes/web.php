<?php

use App\Http\Controllers\PostController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Models\Library;
use App\Models\Post;

Route::get('/', function () {
    try {
        $recent_harari_posts = Post::orderBy('created_at', 'desc')->take(3)->where('language', 'har')->get();
        $recent_english_posts = Post::orderBy('created_at', 'desc')->take(3)->where('language', 'eng')->get();
        $congress_members = DB::table('congress_leaders')->get();
        $messages = Post::where('category', 'message')->get();
        
        // Debug: Check all available categories
        $allCategories = DB::table('catagories')->get();
        \Log::info('All categories:', $allCategories->toArray());
        
        $law_posts = Library::whereHas('category', function($query) {
            $query->where('name', 'law');
        })->orderBy('created_at','desc')->take(5)->get();
        
        \Log::info('Law posts found: ' . $law_posts->count());
        if ($law_posts->isEmpty()) {
            \Log::warning('No law posts found. Checking all libraries:', [
                'total_libraries' => Library::count(),
                'all_libraries' => Library::with('category')->get()->toArray()
            ]);
        }

        return view('welcome', compact('messages', 'congress_members', 'recent_harari_posts', 'recent_english_posts', 'law_posts'));
    } catch (\Exception $e) {
        \Log::error('Welcome page error: ' . $e->getMessage());

        // Return view with empty collections to prevent errors
        return view('welcome', [
            'messages' => collect(),
            'congress_members' => collect()
        ]);
    }
});
Route::get('/about', function () {
    $members = \DB::table('congress_leaders')->get();
    return view('about', compact('members'));
})->name('about');

Route::get('/contact', function () {
    return view('contact');
})->name('contact');

Route::get('/p', function () {

        $posts_harari = Post::where('language', 'har')
                    ->orderBy('created_at', 'desc')
                    ->take(10)
                    ->get();
        $posts_english = Post::where('language', 'eng')
                    ->orderBy('created_at', 'desc')
                    ->take(10)
                    ->get();
        $posts_amharic = Post::where('language', 'am')
                    ->orderBy('created_at', 'desc')
                    ->take(10)
                    ->get();

        $categories = \DB::table('catagories')->get();


    return view('postView', compact('posts_harari','posts_english','posts_amharic', 'categories'));
})->name('postView');



Route::get('/dashboard', function () {
    $subscriptions = \DB::table('subscriptions')->get();
    $numberOfSubscriptions = $subscriptions->count();

    $posts = Post::all();
    $numberOfPosts = $posts->count();
    $numberOfPostsByCategory = $posts->groupBy('category')->map->count();

    // Get posts grouped by date
    $postsByDate = $posts->groupBy(function($post) {
        return $post->created_at->format('Y-m-d');
    })->map->count();

    // Get subscriptions grouped by date
    $subscriptionsByDate = $subscriptions->groupBy(function($subscription) {
        return \Carbon\Carbon::parse($subscription->created_at)->format('Y-m-d');
    })->map->count();

    // Fill in missing dates with zero posts
    $postsOverTime = [];
    if ($postsByDate->isNotEmpty()) {
        $startDate = $posts->min('created_at')->startOfDay();
        $endDate = $posts->max('created_at')->startOfDay();

        $currentDate = $startDate;
        while ($currentDate <= $endDate) {
            $dateString = $currentDate->format('Y-m-d');
            $postsOverTime[$dateString] = $postsByDate[$dateString] ?? 0;
            $currentDate->addDay();
        }
    }

    // Fill in missing dates with zero subscriptions
    $subscriptionsOverTime = [];
    if ($subscriptionsByDate->isNotEmpty()) {
        $startDate = $subscriptions->min('created_at')
            ? \Carbon\Carbon::parse($subscriptions->min('created_at'))->startOfDay()
            : now()->subDays(30)->startOfDay();
        $endDate = $subscriptions->max('created_at')
            ? \Carbon\Carbon::parse($subscriptions->max('created_at'))->startOfDay()
            : now()->startOfDay();

        $currentDate = $startDate;
        while ($currentDate <= $endDate) {
            $dateString = $currentDate->format('Y-m-d');
            $subscriptionsOverTime[$dateString] = $subscriptionsByDate[$dateString] ?? 0;
            $currentDate->addDay();
        }
    }

    return view('dashboard', compact(
        'numberOfPosts',
        'numberOfPostsByCategory',
        'postsOverTime',
        'numberOfSubscriptions',
        'subscriptions',
        'subscriptionsOverTime'
    ));
})->middleware(['auth', 'verified'])->name('dashboard');


// Subscription Routes
Route::post('/subscribe', [App\Http\Controllers\SubScription::class, 'subscribe'])->name('subscribe');

// Public Library Route
Route::get('/public-library', [App\Http\Controllers\LibController::class, 'publicIndex'])->name('public.library');
Route::get('/library/view/{id}', [App\Http\Controllers\LibController::class, 'view'])->name('library.view');
Route::get('/library/preview-text/{id}', [App\Http\Controllers\LibController::class, 'previewText'])->name('library.preview-text');

// Post Routes
Route::get('/load-more-posts/{clickCount}/{language}', [PostController::class, 'loadMorePosts']);

Route::get('/download/{id}', [App\Http\Controllers\LibController::class, 'download'])->name('library.download');

// Profile and Post Management Routes
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // FIX: Move specific routes BEFORE parameterized routes
    Route::get('/posts/create', [PostController::class, 'create'])->name('post.create');
    Route::post('/posts/store', [PostController::class, 'store'])->name('post.store');
    Route::delete('/posts/{id}', [PostController::class, 'delete_post'])->name('posts.delete');
    // or if using resource routes:
    // Route::resource('posts', PostController::class);

    // This should come AFTER specific routes
    Route::get('/posts', [PostController::class, 'post'])->name('post.view');
    // Category Routes
    Route::get('/category', [App\Http\Controllers\CatagoryController::class, 'view'])->name('post.category');
    Route::post('/category/store', [App\Http\Controllers\CatagoryController::class, 'store'])->name('category.store');
    Route::delete('/category/destroy/{id}', [App\Http\Controllers\CatagoryController::class, 'destroy'])->name('category.destroy');
    Route::put('/category/update/{id}', [App\Http\Controllers\CatagoryController::class, 'update'])->name('category.update');

    // Congress Leaders Routes
    Route::get('/congress', [App\Http\Controllers\CongressController::class, 'view'])->name('congress.view');
    Route::post('/congress/store', [App\Http\Controllers\CongressController::class, 'store'])->name('congress.store');
    Route::put('/congress/update/{id}', [App\Http\Controllers\CongressController::class, 'update'])->name('congress.update');
    Route::delete('/congress/destroy/{id}', [App\Http\Controllers\CongressController::class, 'destroy'])->name('congress.destroy');

    // Library Routes
    Route::get('/library', [App\Http\Controllers\LibController::class, 'index'])->name('library.index');
    Route::post('/library/store', [App\Http\Controllers\LibController::class, 'store'])->name('library.store');
    Route::delete('/library/{id}', [App\Http\Controllers\LibController::class, 'destroy'])->name('library.destroy');
});
require __DIR__.'/auth.php';
