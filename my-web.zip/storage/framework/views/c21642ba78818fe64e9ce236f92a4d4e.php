<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e(__('Category Management')); ?>

                </h2>
                <p class="text-sm text-gray-600 mt-1">
                    <?php echo e(__("Manage your post categories here.")); ?>

                </p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Success/Error Messages -->
            <?php if(session('success')): ?>
                <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Add Category Form -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Add New Category</h3>
                        <form method="POST" action="<?php echo e(route('category.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label for="name" class="block text-sm font-medium text-gray-700">Category Name (English)</label>
                                <input type="text" name="name" id="name" required
                                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="Enter category name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-4">
                                <label for="am" class="block text-sm font-medium text-gray-700">Category Name (Amharic)</label>
                                <input type="text" name="am" id="am" required
                                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="Enter category in Amharic">
                                <?php $__errorArgs = ['am'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-4">
                                <label for="har" class="block text-sm font-medium text-gray-700">Category Name (Harari)</label>
                                <input type="text" name="har" id="har" required
                                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="Enter category in Harari">
                                <?php $__errorArgs = ['har'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-4">
                                <label for="description" class="block text-sm font-medium text-gray-700">Description (English)</label>
                                <textarea name="description" id="description" rows="3"
                                          class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                          placeholder="Enter category description (optional)"></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit"
                                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition duration-200">
                                Add Category
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Categories List -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Existing Categories</h3>

                        <?php if($categories->count() > 0): ?>
                            <div class="space-y-3" id="categories-list">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="category-item flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                                         data-category-id="<?php echo e($category->id); ?>">
                                        <!-- Display Mode -->
                                        <div class="display-mode flex items-center justify-between w-full">
                                            <div>
                                                <span class="text-gray-800 font-medium"><?php echo e($category->name); ?></span>
                                                <div class="text-sm text-gray-600 mt-1 space-y-1">
                                                    <?php if($category->am): ?>
                                                        <div><span class="font-medium">Amharic:</span> <?php echo e($category->am); ?></div>
                                                    <?php endif; ?>
                                                    <?php if($category->har): ?>
                                                        <div><span class="font-medium">Harari:</span> <?php echo e($category->har); ?></div>
                                                    <?php endif; ?>
                                                    <?php if($category->description): ?>
                                                        <div><span class="font-medium">Description:</span> <?php echo e($category->description); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="flex space-x-2">
                                                <button type="button" onclick="enableEditMode(<?php echo e($category->id); ?>)"
                                                        class="text-blue-600 hover:text-blue-800 text-sm font-medium transition duration-200">
                                                    Update
                                                </button>
                                                <form method="POST" action="<?php echo e(route('category.destroy', $category->id)); ?>" class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                            onclick="return confirm('Are you sure you want to delete this category?')"
                                                            class="text-red-600 hover:text-red-800 text-sm font-medium transition duration-200">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>

                                        <!-- Edit Mode -->
                                        <div class="edit-mode hidden w-full">
                                            <form method="POST" action="<?php echo e(route('category.update', $category->id)); ?>"
                                                  class="flex flex-col space-y-3">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <input type="text" name="name" value="<?php echo e($category->name); ?>" required
                                                       class="border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                                       placeholder="Category name (English)">
                                                <input type="text" name="am" value="<?php echo e($category->am); ?>" required
                                                       class="border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                                       placeholder="Category name (Amharic)">
                                                <input type="text" name="har" value="<?php echo e($category->har); ?>" required
                                                       class="border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                                       placeholder="Category name (Harari)">
                                                <textarea name="description" rows="2"
                                                          class="border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                                          placeholder="Category description (optional)"><?php echo e($category->description); ?></textarea>
                                                <div class="flex space-x-2">
                                                    <button type="submit"
                                                            class="bg-green-600 text-white py-2 px-3 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition duration-200 text-sm">
                                                        Save
                                                    </button>
                                                    <button type="button" onclick="disableEditMode(<?php echo e($category->id); ?>)"
                                                            class="bg-gray-600 text-white py-2 px-3 rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-200 text-sm">
                                                        Cancel
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <p class="text-gray-500 text-center py-4">No categories found. Add your first category!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php $__env->startPush('styles'); ?>
<style>
    .category-item { transition: all 0.3s ease; }
    .edit-mode { transition: all 0.3s ease; }
    .hidden { display: none !important; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function enableEditMode(categoryId) {
        const categoryItem = document.querySelector(`.category-item[data-category-id="${categoryId}"]`);
        const displayMode = categoryItem.querySelector('.display-mode');
        const editMode = categoryItem.querySelector('.edit-mode');

        displayMode.classList.add('hidden');
        editMode.classList.remove('hidden');
        editMode.querySelector('input[name="name"]').focus();
    }

    function disableEditMode(categoryId) {
        const categoryItem = document.querySelector(`.category-item[data-category-id="${categoryId}"]`);
        categoryItem.querySelector('.display-mode').classList.remove('hidden');
        categoryItem.querySelector('.edit-mode').classList.add('hidden');
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const activeEdit = document.querySelector('.edit-mode:not(.hidden)');
            if (activeEdit) {
                const categoryId = activeEdit.closest('.category-item').getAttribute('data-category-id');
                disableEditMode(categoryId);
            }
        }
    });

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.edit-mode') && !e.target.closest('.display-mode .text-blue-600')) {
            const activeEdit = document.querySelector('.edit-mode:not(.hidden)');
            if (activeEdit && !activeEdit.contains(e.target)) {
                const categoryId = activeEdit.closest('.category-item').getAttribute('data-category-id');
                disableEditMode(categoryId);
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>>
<?php /**PATH /home/omerkemal/Desktop/post-app/resources/views/post/category.blade.php ENDPATH**/ ?>