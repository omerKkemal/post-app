<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\User;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('libraries', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->foreignId('catagory_id')->constrained('catagories')->onDelete('cascade');
            $table->string('location');
            $table->string('description')->nullable();
            $table->foreignId('user_id')->constrained()->onDelete('cascade'); // Add this
            $table->timestamps();
        });
    }

    public function user(){
        return $this -> belongsTo(User::class);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('libraries');
    }
};
