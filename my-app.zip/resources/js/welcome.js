// Welcome page small interactions
document.addEventListener('DOMContentLoaded', function() {
    console.log('Welcome page loaded');
});
