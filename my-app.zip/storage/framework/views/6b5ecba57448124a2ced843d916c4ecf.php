<!DOCTYPE html>
<html>
<head>
    <title>Community Message</title>
</head>
<body>
    <h1>New Community Message</h1>
    <p><strong>Title:</strong> <?php echo e($post->title); ?></p>
    <p><strong>Message:</strong></p>
    <p><?php echo e($post->description); ?></p>
    <?php if($post->media_url): ?>
        <p><strong>Attachments:</strong></p>
        <?php $__currentLoopData = explode(',', $post->media_url); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><a href="<?php echo e(Storage::url($media)); ?>"><?php echo e(basename($media)); ?></a></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <p>Posted by: <?php echo e($post->user->name ?? 'Unknown'); ?></p>
</body>
</html>
<?php /**PATH /home/omer/Desktop/post-app/resources/views/emails/community_message.blade.php ENDPATH**/ ?>