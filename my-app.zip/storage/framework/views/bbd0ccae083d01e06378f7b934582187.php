<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e(__('Public Library')); ?>

                </h2>
                <p class="text-sm text-gray-600 mt-1">
                    Browse and download public documents
                </p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Library Files Grid -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">
                        Available Documents (<?php echo e($libraries->count()); ?>)
                    </h3>

                    <?php if($libraries->count() > 0): ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <?php $__currentLoopData = $libraries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $library): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="library-item bg-gray-50 rounded-lg p-4 border border-gray-200 hover:shadow-md transition-shadow duration-200">
                                    <!-- File Preview -->
                                    <div class="flex items-center justify-center h-32 bg-white rounded-lg mb-3 border">
                                        <?php
                                            $extension = pathinfo($library->location, PATHINFO_EXTENSION);
                                            $iconClass = match(strtolower($extension)) {
                                                'pdf' => 'fas fa-file-pdf text-red-500',
                                                'doc', 'docx' => 'fas fa-file-word text-blue-500',
                                                'txt' => 'fas fa-file-alt text-gray-500',
                                                'xls', 'xlsx' => 'fas fa-file-excel text-green-500',
                                                'ppt', 'pptx' => 'fas fa-file-powerpoint text-orange-500',
                                                default => 'fas fa-file text-gray-400'
                                            };
                                        ?>
                                        <i class="<?php echo e($iconClass); ?> text-4xl"></i>
                                    </div>

                                    <!-- File Info -->
                                    <div class="flex-1">
                                        <h4 class="text-sm font-medium text-gray-900 truncate" title="<?php echo e($library->name); ?>">
                                            <?php echo e($library->name); ?>

                                        </h4>
                                        <?php if($library->description): ?>
                                            <p class="text-xs text-gray-600 mt-1 line-clamp-2" title="<?php echo e($library->description); ?>">
                                                <?php echo e($library->description); ?>

                                            </p>
                                        <?php endif; ?>
                                        <div class="flex items-center justify-between mt-2">
                                            <span class="text-xs text-gray-500">
                                                <?php echo e($library->created_at->format('M d, Y')); ?>

                                            </span>
                                            <span class="text-xs text-gray-500 uppercase">
                                                <?php echo e(strtoupper($extension)); ?>

                                            </span>
                                        </div>
                                    </div>

                                    <!-- Download Action -->
                                    <div class="flex justify-center mt-3 pt-3 border-t border-gray-200">
                                        <a href="<?php echo e(route('library.download', $library->id)); ?>"
                                           class="inline-flex items-center px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-sm transition-all duration-200">
                                            <i class="fas fa-download mr-2"></i>
                                            Download
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-12">
                            <i class="fas fa-folder-open text-6xl text-gray-300 mb-4"></i>
                            <h3 class="text-lg font-medium text-gray-900 mb-2">No documents available</h3>
                            <p class="text-gray-500">Check back later for new documents</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <style>
    .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/omer/Desktop/post-app/resources/views/public_lib.blade.php ENDPATH**/ ?>