<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e(__('Congress Leaders Management')); ?>

                </h2>
                <p class="text-sm text-gray-600 mt-1">
                    <?php echo e(__("Manage congress leaders here.")); ?>

                </p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Success/Error Messages -->
            <?php if(session('success')): ?>
                <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Add Congress Leader Form -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Add New Congress Leader</h3>
                        <form method="POST" action="<?php echo e(route('congress.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <!-- File Upload Section -->
                            <div class="mb-8">
                                <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['value' => __('Media Attachment'),'class' => 'text-lg font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Media Attachment')),'class' => 'text-lg font-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                                <p class="text-sm text-gray-600 mb-3">
                                    Add an image to represent the leader (Max: 10MB)
                                </p>

                                <div class="relative flex flex-col items-center justify-center gap-4 px-6 py-12 border-2 border-dashed border-gray-300 rounded-xl bg-white">
                                    <div class="text-center">
                                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
                                        <h3 class="text-lg font-semibold text-gray-700 mb-2" id="fileLabel">
                                            Drop your file here
                                        </h3>
                                        <p class="text-sm text-gray-500 mb-4">
                                            or use the button below
                                        </p>

                                        <p class="text-xs text-gray-400 mt-3">
                                            Supports: JPG, PNG (Max 10MB)
                                        </p>
                                    </div>

                                    <input class="sr-only" type="file" name="media" id="media" accept="image/*">
                                </div>

                                <!-- Button placed outside the dropzone to prevent event conflicts -->
                                <div class="mt-4 text-center">
                                    <button type="button"
                                           id="mediaSelectButton"
                                           class="inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-sm transition-all duration-200 cursor-pointer">
                                        <i class="fas fa-plus-circle mr-2"></i>
                                        Choose File
                                    </button>
                                </div>

                                <!-- File info display -->
                                <div id="fileInfo" class="mt-3 hidden">
                                    <div class="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                                        <div class="flex items-center">
                                            <i class="fas fa-file-image text-blue-500 mr-2"></i>
                                            <span id="fileName" class="text-sm font-medium"></span>
                                            <span id="fileSize" class="text-xs text-gray-500 ml-2"></span>
                                        </div>
                                        <button type="button" id="removeFile" class="text-red-500 hover:text-red-700">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>

                                    <!-- Image preview -->
                                    <div id="filePreviewWrapper" class="mt-3 hidden">
                                        <img id="filePreview" src="" alt="Selected image preview" class="w-32 h-32 object-cover rounded-lg border" />
                                    </div>
                                </div>
                            </div>

                            <!-- Input Fields -->
                            <div class="mb-4">
                                <label for="name" class="block text-sm font-medium text-gray-700">Name *</label>
                                <input type="text"
                                       name="name"
                                       id="name"
                                       required
                                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="Enter congress leader name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-4">
                                <label for="position" class="block text-sm font-medium text-gray-700">Position *</label>
                                <input type="text"
                                       name="position"
                                       id="position"
                                       required
                                       class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="Enter position">
                                <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-4">
                                <label for="bio" class="block text-sm font-medium text-gray-700">Bio</label>
                                <textarea name="bio"
                                          id="bio"
                                          rows="3"
                                          class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                          placeholder="Enter a brief bio or message (optional)"></textarea>
                                <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit"
                                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition duration-200">
                                Add Congress Leader
                            </button>
                        </form>

                        <!-- Scripts for file UI -->
                        <script>
                        document.addEventListener('DOMContentLoaded', function () {

                            const mediaInput = document.getElementById('media');
                            const mediaSelectButton = document.getElementById('mediaSelectButton');
                            const fileLabel = document.getElementById('fileLabel');
                            const fileInfo = document.getElementById('fileInfo');
                            const fileName = document.getElementById('fileName');
                            const fileSize = document.getElementById('fileSize');
                            const removeFileBtn = document.getElementById('removeFile');
                            const filePreview = document.getElementById('filePreview');
                            const filePreviewWrapper = document.getElementById('filePreviewWrapper');
                            const dropzone = mediaInput ? mediaInput.closest('.border-dashed') : null;

                            if (mediaSelectButton && mediaInput) {
                                mediaSelectButton.addEventListener('click', function (e) {
                                    e.stopPropagation();
                                    mediaSelectButton.disabled = true;
                                    mediaInput.click();
                                    // Re-enable after a short delay
                                    setTimeout(() => {
                                        mediaSelectButton.disabled = false;
                                    }, 100);
                                });
                            }

                            if (mediaInput) {
                                mediaInput.addEventListener('change', function (e) {
                                    const file = e.target.files[0];
                                    if (file) updateFileInfo(file);
                                });
                            }

                            if (removeFileBtn) {
                                removeFileBtn.addEventListener('click', function (e) {
                                    e.stopPropagation();
                                    if (mediaInput) mediaInput.value = '';
                                    if (fileInfo) fileInfo.classList.add('hidden');
                                    if (fileLabel) fileLabel.textContent = 'Drop your file here';
                                    if (filePreview) {
                                        filePreview.src = '';
                                        if (filePreviewWrapper) filePreviewWrapper.classList.add('hidden');
                                    }
                                });
                            }

                            if (dropzone) {
                                dropzone.addEventListener('dragover', function (e) {
                                    e.preventDefault();
                                    dropzone.classList.add('border-blue-500', 'bg-blue-50');
                                });

                                dropzone.addEventListener('dragleave', function (e) {
                                    e.preventDefault();
                                    dropzone.classList.remove('border-blue-500', 'bg-blue-50');
                                });

                                dropzone.addEventListener('drop', function (e) {
                                    e.preventDefault();
                                    dropzone.classList.remove('border-blue-500', 'bg-blue-50');

                                    const file = e.dataTransfer.files[0];
                                    if (!file) return;

                                    if (!file.type.startsWith('image/')) {
                                        alert('Only image files are allowed.');
                                        return;
                                    }

                                    if (file.size > 10 * 1024 * 1024) {
                                        alert('Max file size is 10MB.');
                                        return;
                                    }

                                    try {
                                        const dt = new DataTransfer();
                                        dt.items.add(file);
                                        if (mediaInput) mediaInput.files = dt.files;
                                        updateFileInfo(file);
                                    } catch (err) {
                                        alert('Your browser does not support drag-and-drop file assignment. Please use the "Choose File" button.');
                                    }
                                });
                            }

                            function updateFileInfo(file) {
                                if (fileName) fileName.textContent = file.name;
                                if (fileSize) fileSize.textContent = formatFileSize(file.size);
                                if (fileLabel) fileLabel.textContent = 'File selected';
                                if (fileInfo) fileInfo.classList.remove('hidden');

                                if (filePreview) {
                                    try {
                                        const url = URL.createObjectURL(file);
                                        filePreview.src = url;
                                        if (filePreviewWrapper) filePreviewWrapper.classList.remove('hidden');
                                    } catch (err) {
                                        // ignore preview errors
                                    }
                                }
                            }

                            function formatFileSize(bytes) {
                                const units = ['Bytes', 'KB', 'MB', 'GB'];
                                if (!bytes) return '0 Bytes';
                                const i = Math.floor(Math.log(bytes) / Math.log(1024));
                                return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + units[i];
                            }
                        });
                        </script>
                    </div>
                </div>

                <!-- Congress Leaders List -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">
                            Existing Congress Leaders (<?php echo e($congress_leaders->count()); ?>)
                        </h3>

                        <?php if($congress_leaders->count() > 0): ?>
                            <div class="space-y-3" id="congress-leaders-list">
                                <?php $__currentLoopData = $congress_leaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="congress-leader-item flex items-center justify-between p-3 bg-gray-50 rounded-lg transition-all duration-300 hover:shadow"
                                         data-leader-id="<?php echo e($leader->id); ?>">
                                        <!-- Display Mode -->
                                        <div class="display-mode flex items-center justify-between w-full">
                                            <div class="flex items-center gap-3">
                                                <?php if($leader->photo_url): ?>
                                                    <img src="<?php echo e(asset('storage/' . $leader->photo_url)); ?>"
                                                         class="w-10 h-10 rounded-full object-cover border"
                                                         alt="<?php echo e($leader->name); ?>">
                                                <?php endif; ?>
                                                <div>
                                                    <span class="text-gray-800 font-medium"><?php echo e($leader->name); ?></span>
                                                    <p class="text-sm text-gray-600 mt-1"><?php echo e($leader->position); ?></p>
                                                </div>
                                            </div>

                                            <div class="flex space-x-2">
                                                <button type="button"
                                                        onclick="enableEditMode(<?php echo e($leader->id); ?>)"
                                                        class="text-blue-600 hover:text-blue-800 text-sm font-medium transition duration-200">
                                                    Update
                                                </button>
                                                <form method="POST" action="<?php echo e(route('congress.destroy', $leader->id)); ?>" class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                            onclick="return confirm('Are you sure you want to delete this congress leader?')"
                                                            class="text-red-600 hover:text-red-800 text-sm font-medium transition duration-200">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>

                                        <!-- Edit Mode -->
                                        <div class="edit-mode hidden w-full flex flex-col space-y-3 mt-3">
                                            <form method="POST" action="<?php echo e(route('congress.update', $leader->id)); ?>" class="flex flex-col space-y-3">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>

                                                <input type="text"
                                                       name="name"
                                                       value="<?php echo e($leader->name); ?>"
                                                       required
                                                       class="border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                                       placeholder="Congress leader name">

                                                <input type="text"
                                                       name="position"
                                                       value="<?php echo e($leader->position); ?>"
                                                       required
                                                       class="border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                                       placeholder="Position">

                                                <div class="flex space-x-2">
                                                    <button type="submit"
                                                            class="bg-green-600 text-white py-2 px-3 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition duration-200 text-sm">
                                                        Save
                                                    </button>
                                                    <button type="button"
                                                            onclick="disableEditMode(<?php echo e($leader->id); ?>)"
                                                            class="bg-gray-600 text-white py-2 px-3 rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-200 text-sm">
                                                        Cancel
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <p class="text-gray-500 text-center py-4">No congress leaders found. Add your first congress leader!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/omer/Desktop/post-app/resources/views/post/congress.blade.php ENDPATH**/ ?>